"""Recycling Drive Dashboard core package."""
