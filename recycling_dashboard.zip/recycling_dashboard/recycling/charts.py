"""Matplotlib charts (headless-safe)."""
import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

GREEN, RED = "#2e7d32", "#c62828"


def by_category(summary):
    rows = summary["categories"]
    fig, ax = plt.subplots(figsize=(7, 3.8))
    names = [r["category"] for r in rows]
    ax.bar(names, [r["total_kg"] for r in rows], color=GREEN, label="Collected")
    ax.scatter(names, [r["goal_kg"] for r in rows], marker="_", s=900, linewidths=2.5, color=RED, label="Goal")
    ax.set_ylabel("kg"); ax.set_title("Collected vs goal by category"); ax.legend()
    ax.tick_params(axis="x", rotation=30); fig.tight_layout()
    return fig


def trend(summary):
    fig, ax = plt.subplots(figsize=(7, 3.8))
    daily = summary["daily"]
    if not daily:
        ax.text(0.5, 0.5, "No data yet", ha="center"); return fig
    days = [d for d, _ in daily]
    vals = [v for _, v in daily]
    cum, run = [], 0
    for v in vals:
        run += v; cum.append(run)
    ax.bar(days, vals, color="#81c784", label="Daily kg")
    ax2 = ax.twinx(); ax2.plot(days, cum, color=GREEN, marker="o", ms=3, label="Cumulative kg")
    ax.set_title("Collection trend"); ax.set_ylabel("Daily kg"); ax2.set_ylabel("Cumulative kg")
    step = max(1, len(days) // 8)
    ax.set_xticks(days[::step]); ax.tick_params(axis="x", rotation=45); fig.tight_layout()
    return fig


def distribution(summary):
    fig, ax = plt.subplots(figsize=(5, 3.8))
    rows = [r for r in summary["categories"] if r["total_kg"] > 0]
    if rows:
        ax.pie([r["total_kg"] for r in rows], labels=[r["category"] for r in rows], autopct="%1.0f%%", startangle=90)
    else:
        ax.text(0.5, 0.5, "No data yet", ha="center")
    ax.set_title("Share of total weight"); fig.tight_layout()
    return fig


def png_bytes(fig) -> bytes:
    buf = io.BytesIO(); fig.savefig(buf, format="png", dpi=150); return buf.getvalue()
