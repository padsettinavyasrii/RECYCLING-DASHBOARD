"""Entry data model + defensive input validation."""
from __future__ import annotations
import math, re, uuid
from dataclasses import dataclass, asdict
from datetime import date, datetime

CATEGORIES = ["Paper", "Cardboard", "Plastic", "Glass", "Metal", "E-Waste", "Batteries"]
MIN_KG, MAX_KG = 0.05, 500.0
_NAME_RE = re.compile(r"^[A-Za-z0-9 .,'&_-]{2,40}$")


class ValidationError(ValueError):
    def __init__(self, errors):
        self.errors = list(errors)
        super().__init__("; ".join(self.errors))


@dataclass
class Entry:
    id: str
    date: str          # ISO yyyy-mm-dd
    category: str
    weight_kg: float
    collector: str     # drive point / team / location
    notes: str = ""

    def to_dict(self):
        return asdict(self)


def parse_weight(raw) -> float:
    text = str(raw if raw is not None else "").strip().lower().replace("kg", "").replace(",", ".").strip()
    if not text:
        raise ValueError("Weight is required.")
    try:
        val = float(text)
    except ValueError:
        raise ValueError(f"'{raw}' is not a valid number.") from None
    if not math.isfinite(val):
        raise ValueError("Weight must be a finite number.")
    if not MIN_KG <= val <= MAX_KG:
        raise ValueError(f"Weight must be between {MIN_KG} and {MAX_KG} kg.")
    return round(val, 2)


def parse_date(raw) -> date:
    if isinstance(raw, datetime):
        d = raw.date()
    elif isinstance(raw, date):
        d = raw
    else:
        try:
            d = date.fromisoformat(str(raw).strip())
        except ValueError:
            raise ValueError(f"'{raw}' is not a valid date (use YYYY-MM-DD).") from None
    if d > date.today():
        raise ValueError("Date cannot be in the future.")
    return d


def validate_entry(date_val, category, weight, collector, notes="", entry_id=None) -> Entry:
    errors, d, w, cat = [], None, None, None
    try: d = parse_date(date_val)
    except ValueError as e: errors.append(str(e))
    try: w = parse_weight(weight)
    except ValueError as e: errors.append(str(e))
    cat = next((c for c in CATEGORIES if c.lower() == str(category or "").strip().lower()), None)
    if cat is None:
        errors.append(f"Category must be one of: {', '.join(CATEGORIES)}.")
    who = re.sub(r"\s+", " ", str(collector or "")).strip()
    if not _NAME_RE.match(who):
        errors.append("Collector/location must be 2-40 characters (letters, numbers, spaces, . , ' & _ -).")
    note = re.sub(r"[\x00-\x1f]+", " ", str(notes or "")).strip()
    if len(note) > 200:
        errors.append("Notes must be 200 characters or fewer.")
    if errors:
        raise ValidationError(errors)
    return Entry(str(entry_id or uuid.uuid4().hex[:8]), d.isoformat(), cat, w, who, note)
