"""Exports (Markdown / audit log / CSV) and bulk CSV import with row-level errors."""
from __future__ import annotations
import csv, io
from datetime import datetime
from .validation import ValidationError, validate_entry

FIELDS = ["id", "date", "category", "weight_kg", "collector", "notes"]


def to_csv(entries) -> str:
    buf = io.StringIO(); w = csv.DictWriter(buf, FIELDS); w.writeheader()
    for e in sorted(entries, key=lambda e: e.date): w.writerow(e.to_dict())
    return buf.getvalue()


def to_markdown(entries, s) -> str:
    L = [f"# Recycling Drive Report", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", "",
         f"- **Total collected:** {s['total_kg']} kg across {s['count']} entries",
         f"- **Average per entry:** {s['avg_kg']} kg", f"- **Top category:** {s['top_category']}",
         f"- **Trend:** {s['trend']} ({s['last7_kg']} kg last 7 days)", "",
         "## Progress by category", "", "| Category | Entries | Total kg | Goal kg | % of goal | Status |", "|---|---:|---:|---:|---:|---|"]
    L += [f"| {r['category']} | {r['entries']} | {r['total_kg']} | {r['goal_kg']} | {r['pct_of_goal']}% | {r['status']} |"
          for r in s["categories"]]
    L += ["", "## Warnings", ""] + ([f"- {w}" for w in s["warnings"]] or ["- None"])
    return "\n".join(L) + "\n"


def to_audit_log(entries, s) -> str:
    L = [f"RECYCLING DRIVE AUDIT LOG - {datetime.now():%Y-%m-%d %H:%M:%S}",
         f"records={s['count']} total_kg={s['total_kg']} avg_kg={s['avg_kg']}", "-" * 72]
    L += [f"{e.date} | {e.id} | {e.category:<9} | {e.weight_kg:>7.2f} kg | {e.collector} | {e.notes}"
          for e in sorted(entries, key=lambda e: e.date)]
    L += ["-" * 72, "WARNINGS:"] + ([f"  * {w}" for w in s["warnings"]] or ["  none"])
    return "\n".join(L) + "\n"


def import_csv(text: str):
    """Return (entries, errors); errors = [{'row': n, 'error': msg}]."""
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        return [], [{"row": 1, "error": "File is empty or has no header row."}]
    reader.fieldnames = [{'weight': 'weight_kg'}.get(h.strip().lower(), h.strip().lower()) for h in reader.fieldnames]
    missing = {"date", "category", "weight_kg", "collector"} - set(reader.fieldnames)
    if missing:
        return [], [{"row": 1, "error": f"Missing required column(s): {', '.join(sorted(missing))}"}]
    entries, errors = [], []
    for n, row in enumerate(reader, start=2):
        try:
            entries.append(validate_entry(row.get("date"), row.get("category"), row.get("weight_kg"),
                                          row.get("collector"), row.get("notes") or ""))
        except ValidationError as exc:
            errors.append({"row": n, "error": "; ".join(exc.errors)})
    return entries, errors
