"""Business logic: totals, goals, trends, warning flags."""
from __future__ import annotations
import statistics
from collections import Counter, defaultdict
from datetime import date, timedelta
from .validation import CATEGORIES

# Drive targets in kg per category (edit freely)
GOALS = {"Paper": 150, "Cardboard": 120, "Plastic": 100, "Glass": 100,
         "Metal": 80, "E-Waste": 40, "Batteries": 10}
IDLE_DAYS, LOW_PCT, ANOMALY_Z, ANOMALY_KG = 7, 25, 2.5, 250


def status_for(pct: float) -> str:
    if pct >= 100: return "✅ Goal met"
    if pct >= 50: return "🟡 On track"
    if pct >= 25: return "🟠 Needs a push"
    return "🔴 Behind"


def daily_totals(entries):
    by_day = defaultdict(float)
    for e in entries:
        by_day[e.date] += e.weight_kg
    return sorted(by_day.items())


def summarize(entries, today: date | None = None) -> dict:
    today = today or date.today()
    totals, counts = defaultdict(float), Counter()
    for e in entries:
        totals[e.category] += e.weight_kg
        counts[e.category] += 1
    cats = []
    for c in CATEGORIES:
        pct = totals[c] / GOALS[c] * 100
        cats.append({"category": c, "entries": counts[c], "total_kg": round(totals[c], 2),
                     "goal_kg": GOALS[c], "pct_of_goal": round(pct, 1), "status": status_for(pct)})
    total = round(sum(totals.values()), 2)
    cut = lambda a, b: sum(e.weight_kg for e in entries
                           if today - timedelta(days=a) < date.fromisoformat(e.date) <= today - timedelta(days=b))
    last7, prev7 = round(cut(7, 0), 2), round(cut(14, 7), 2)
    if prev7 > 0:
        change = (last7 - prev7) / prev7 * 100
        trend = f"{'▲' if change >= 0 else '▼'} {abs(change):.0f}% vs previous 7 days"
    else:
        trend = "New activity this week" if last7 else "No recent activity"
    s = {"count": len(entries), "total_kg": total,
         "avg_kg": round(total / len(entries), 2) if entries else 0.0,
         "top_category": max(cats, key=lambda r: r["total_kg"])["category"] if entries else "-",
         "last7_kg": last7, "prev7_kg": prev7, "trend": trend,
         "categories": cats, "daily": daily_totals(entries)}
    s["warnings"] = warnings_for(entries, cats, today)
    return s


def warnings_for(entries, cats, today) -> list[str]:
    out = []
    if not entries:
        return ["No records yet - add an entry or load the sample dataset."]
    latest = max(date.fromisoformat(e.date) for e in entries)
    if (today - latest).days > IDLE_DAYS:
        out.append(f"⏰ No collections logged for {(today - latest).days} days (last: {latest}).")
    for r in cats:
        if r["pct_of_goal"] < LOW_PCT:
            out.append(f"📉 {r['category']} is at {r['pct_of_goal']:.0f}% of its {r['goal_kg']} kg goal.")
    w = [e.weight_kg for e in entries]
    if len(w) >= 8:
        mean, sd = statistics.mean(w), statistics.pstdev(w)
        for e in entries:
            if e.weight_kg >= ANOMALY_KG or (sd and (e.weight_kg - mean) / sd > ANOMALY_Z):
                out.append(f"🚨 Unusually large entry: {e.weight_kg} kg {e.category} on {e.date} ({e.collector}).")
    dupes = Counter((e.date, e.category, e.weight_kg, e.collector) for e in entries)
    for (d, c, kg, who), n in dupes.items():
        if n > 1:
            out.append(f"⚠️ Possible duplicate x{n}: {kg} kg {c} on {d} ({who}).")
    return out


def search(entries, keyword="", categories=None):
    k = keyword.strip().lower()
    return [e for e in entries
            if (not categories or e.category in categories)
            and (not k or k in f"{e.category} {e.collector} {e.notes} {e.date}".lower())]
