"""JSON persistence with schema checks, corruption recovery and atomic writes."""
from __future__ import annotations
import json, os, tempfile, time
from pathlib import Path
from .validation import Entry, ValidationError, validate_entry

DEFAULT_PATH = Path(__file__).resolve().parent.parent / "data" / "records.json"
SCHEMA_VERSION = 1


def save(entries, path=DEFAULT_PATH) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"schema_version": SCHEMA_VERSION, "entries": [e.to_dict() for e in entries]}
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
    os.replace(tmp, path)  # atomic: never leaves a half-written file


def load(path=DEFAULT_PATH):
    """Return (entries, warnings). Never raises on missing/corrupt files."""
    path, warnings = Path(path), []
    if not path.exists():
        save([], path)
        return [], warnings
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        rows = raw.get("entries") if isinstance(raw, dict) else raw
        if not isinstance(rows, list):
            raise ValueError("'entries' must be a list")
    except (json.JSONDecodeError, ValueError, OSError, UnicodeDecodeError) as exc:
        backup = path.with_name(f"{path.stem}.corrupt-{int(time.time())}.json")
        try: path.replace(backup)
        except OSError: pass
        save([], path)
        return [], [f"Data file was unreadable ({exc}); backed up to {backup.name} and started fresh."]
    entries = []
    for i, row in enumerate(rows, 1):
        try:
            entries.append(validate_entry(row["date"], row["category"], row["weight_kg"],
                                          row["collector"], row.get("notes", ""), row.get("id")))
        except (ValidationError, KeyError, TypeError, AttributeError) as exc:
            warnings.append(f"Stored record #{i} skipped: {exc}")
    return entries, warnings
