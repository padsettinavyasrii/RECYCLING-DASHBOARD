"""Recycling Drive Dashboard - Streamlit UI.  Run: streamlit run app.py"""
import json
from datetime import date
from pathlib import Path

import matplotlib.pyplot as plt
import streamlit as st

from recycling import analytics, charts, reports, storage
from recycling.validation import CATEGORIES, MAX_KG, MIN_KG, ValidationError, validate_entry

st.set_page_config(page_title="Recycling Drive Dashboard", page_icon="♻️", layout="wide")

if "entries" not in st.session_state:
    st.session_state.entries, st.session_state.load_warnings = storage.load()


def commit(entries):
    storage.save(entries)            # persist on every change -> survives restarts
    st.session_state.entries = entries


entries = st.session_state.entries
summary = analytics.summarize(entries)

# ---------- sidebar ----------
st.sidebar.title("♻️ Recycling Drive")
page = st.sidebar.radio("Navigate", ["📊 Dashboard", "➕ Add Entry", "🔎 Records", "📁 Import / Export"])
st.sidebar.caption(f"{summary['count']} records · {summary['total_kg']} kg collected")
for w in st.session_state.load_warnings:
    st.sidebar.warning(w)
if st.sidebar.button("Load sample data (40 rows)"):
    data = json.loads((Path(__file__).parent / "data" / "sample_data.json").read_text(encoding="utf-8"))
    sample = [validate_entry(r["date"], r["category"], r["weight_kg"], r["collector"], r["notes"]) for r in data["entries"]]
    commit(sample); st.rerun()

# ---------- dashboard ----------
if page == "📊 Dashboard":
    st.title("♻️ Recycling Drive Dashboard")
    st.caption("Track recyclables by category, watch progress against goals, spot problems early.")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total collected", f"{summary['total_kg']} kg")
    c2.metric("Entries", summary["count"])
    c3.metric("Avg per entry", f"{summary['avg_kg']} kg")
    c4.metric("Top category", summary["top_category"])
    st.info(f"**This week:** {summary['last7_kg']} kg · {summary['trend']}")
    for w in summary["warnings"]:
        st.warning(w)
    st.subheader("Progress by category")
    st.dataframe(summary["categories"], hide_index=True, use_container_width=True,
                 column_config={"pct_of_goal": st.column_config.ProgressColumn("% of goal", min_value=0, max_value=100, format="%.0f%%")})
    left, right = st.columns([3, 2])
    for col, fn in ((left, charts.by_category), (right, charts.distribution)):
        fig = fn(summary); col.pyplot(fig); plt.close(fig)
    fig = charts.trend(summary); st.pyplot(fig); plt.close(fig)

# ---------- add entry ----------
elif page == "➕ Add Entry":
    st.title("➕ Log a collection")
    with st.form("add", clear_on_submit=False):
        d = st.date_input("Date", value=date.today(), max_value=date.today())
        cat = st.selectbox("Category", CATEGORIES)
        wt = st.text_input("Weight (kg)", placeholder=f"{MIN_KG} – {MAX_KG}")
        who = st.text_input("Collector / drive point", placeholder="e.g. Library")
        notes = st.text_area("Notes (optional)", max_chars=200)
        ok = st.form_submit_button("Save entry", type="primary")
    if ok:
        try:
            e = validate_entry(d, cat, wt, who, notes)
            commit(entries + [e]); st.success(f"Saved {e.weight_kg} kg of {e.category} ✔"); st.balloons()
        except ValidationError as exc:
            for msg in exc.errors:
                st.error(msg)

# ---------- records ----------
elif page == "🔎 Records":
    st.title("🔎 Records")
    f1, f2, f3 = st.columns([2, 2, 1])
    kw = f1.text_input("Keyword search", placeholder="collector, notes, date…")
    cats = f2.multiselect("Category", CATEGORIES)
    size = f3.selectbox("Rows / page", [10, 25, 50], index=0)
    hits = sorted(analytics.search(entries, kw, cats), key=lambda e: e.date, reverse=True)
    pages = max(1, -(-len(hits) // size))
    pg = st.number_input("Page", 1, pages, 1)
    st.caption(f"{len(hits)} matching records · page {pg}/{pages}")
    st.dataframe([e.to_dict() for e in hits[(pg - 1) * size: pg * size]], hide_index=True, use_container_width=True)
    if hits:
        with st.expander("Delete a record"):
            pick = st.selectbox("Record", hits, format_func=lambda e: f"{e.date} · {e.category} · {e.weight_kg} kg · {e.collector} [{e.id}]")
            if st.button("Delete selected", type="secondary"):
                commit([e for e in entries if e.id != pick.id]); st.rerun()

# ---------- import / export ----------
else:
    st.title("📁 Import / Export")
    st.subheader("Bulk import (CSV)")
    st.caption("Required columns: date, category, weight_kg, collector. Optional: notes.")
    up = st.file_uploader("Choose a CSV", type="csv")
    if up:
        new, errs = reports.import_csv(up.getvalue().decode("utf-8-sig", errors="replace"))
        st.write(f"**{len(new)}** valid rows · **{len(errs)}** rejected")
        if errs:
            st.dataframe(errs, hide_index=True, use_container_width=True)
        if new and st.button("Import valid rows", type="primary"):
            commit(entries + new); st.success(f"Imported {len(new)} rows"); st.rerun()
    st.subheader("Export reports")
    a, b, c, d = st.columns(4)
    a.download_button("Markdown summary", reports.to_markdown(entries, summary), "recycling_report.md")
    b.download_button("Audit log (.txt)", reports.to_audit_log(entries, summary), "recycling_audit.txt")
    c.download_button("Records (.csv)", reports.to_csv(entries), "recycling_records.csv")
    fig = charts.by_category(summary); png = charts.png_bytes(fig); plt.close(fig)
    d.download_button("Chart (.png)", png, "recycling_chart.png", mime="image/png")
