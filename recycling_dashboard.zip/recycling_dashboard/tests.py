import tempfile, json
from pathlib import Path
from recycling import analytics, charts, reports, storage
from recycling.validation import validate_entry, ValidationError
import seed

# validation
for bad in ["abc", "", "-5", "0", "501", "nan", "inf"]:
    try: validate_entry("2020-01-01", "Paper", bad, "Library"); raise SystemExit(f"accepted {bad!r}")
    except ValidationError: pass
try: validate_entry("2999-01-01", "Wood", "5", "!"); raise SystemExit("bad")
except ValidationError as e: assert len(e.errors) == 3, e.errors
assert validate_entry("2024-01-01", "paper", "5,5 kg", " Hall  A ").weight_kg == 5.5

# persistence + corruption recovery
tmp = Path(tempfile.mkdtemp()) / "r.json"
es = seed.build(); storage.save(es, tmp)
loaded, w = storage.load(tmp); assert len(loaded) == 40 and not w
tmp.write_text("{not json"); loaded, w = storage.load(tmp); assert loaded == [] and w
assert storage.load(tmp)[0] == []
tmp.write_text(json.dumps({"entries": [{"date": "x"}]})); assert storage.load(tmp)[1]

# analytics + reports
s = analytics.summarize(es)
assert s["count"] == 40 and s["warnings"]
print("\n".join(s["warnings"]))
assert len(analytics.search(es, "library")) > 0
assert "| Paper" in reports.to_markdown(es, s) and "AUDIT" in reports.to_audit_log(es, s)
ok, errs = reports.import_csv("date,category,weight,collector\n2024-01-01,Glass,5,Hall\nbad,Wood,x,\n")
assert len(ok) == 1 and len(errs) == 1; print(errs)
rt, _ = reports.import_csv(reports.to_csv(es)); assert len(rt) == 40
for f in (charts.by_category, charts.trend, charts.distribution):
    assert charts.png_bytes(f(s))[:4] == b"\x89PNG"; f(analytics.summarize([]))
print("ALL TESTS PASSED")
