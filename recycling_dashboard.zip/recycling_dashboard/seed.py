"""Generate data/sample_data.csv + .json (40 realistic rows incl. edge cases)."""
import json, random
from datetime import date, timedelta
from pathlib import Path
from recycling.validation import validate_entry
from recycling.reports import to_csv

RANGES = {"Paper": (5, 40), "Cardboard": (8, 45), "Plastic": (3, 25), "Glass": (4, 30),
          "Metal": (2, 20), "E-Waste": (1, 12), "Batteries": (0.2, 3)}
WHO = ["Library", "Science Block", "Hostel A", "Hostel B", "Canteen", "Admin Office", "Maple Hall"]


def build(today=None):
    today, rnd = today or date.today(), random.Random(47)
    rows = []
    for _ in range(36):
        c = rnd.choice(list(RANGES)); lo, hi = RANGES[c]
        rows.append((today - timedelta(days=rnd.randint(0, 40)), c, round(rnd.uniform(lo, hi), 1), rnd.choice(WHO), ""))
    rows += [(today - timedelta(days=3), "Batteries", 0.05, "Admin Office", "Boundary: minimum weight"),
             (today - timedelta(days=9), "Cardboard", 300, "Canteen", "Edge case: bulk delivery (anomaly)"),
             (today - timedelta(days=5), "Glass", 12.5, "Hostel A", "Duplicate test"),
             (today - timedelta(days=5), "Glass", 12.5, "Hostel A", "Duplicate test")]
    return [validate_entry(*r) for r in rows]


if __name__ == "__main__":
    d = Path(__file__).parent / "data"; d.mkdir(exist_ok=True)
    entries = sorted(build(), key=lambda e: e.date)
    (d / "sample_data.csv").write_text(to_csv(entries), encoding="utf-8")
    (d / "sample_data.json").write_text(json.dumps({"schema_version": 1, "entries": [e.to_dict() for e in entries]}, indent=2), encoding="utf-8")
    print(f"Wrote {len(entries)} sample entries")
