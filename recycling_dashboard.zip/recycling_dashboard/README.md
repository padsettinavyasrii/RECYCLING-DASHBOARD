# ♻️ Recycling Drive Dashboard (Streamlit)

Track recyclables by category, validate every entry, persist to JSON, search, summarise, chart and export.

## Run
```
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python seed.py            # regenerates data/sample_data.csv + .json (40 rows)
streamlit run app.py
python tests.py           # core-logic tests (no UI needed)
```

## Build plan (maps to the brief's 8 steps)
| # | Step | Where |
|---|------|-------|
| 1 | Project structure + venv + requirements | this folder |
| 2 | Data model (`Entry` dataclass), categories, goals | `recycling/validation.py`, `analytics.GOALS` |
| 3 | Defensive validation (type, range 0.05–500 kg, no future dates, whitelist categories, name regex) | `recycling/validation.py` |
| 4 | Business logic: totals, goal %, status, 7-day trend, warnings | `recycling/analytics.py` |
| 5 | JSON persistence, atomic writes, corrupt-file backup + auto-reset | `recycling/storage.py` |
| 6 | Streamlit navigation: Dashboard / Add / Records / Import-Export | `app.py` |
| 7 | Summary metrics, tables, Matplotlib charts | `analytics.py`, `charts.py` |
| 8 | Seed data incl. edge cases + tests + demo | `seed.py`, `tests.py` |

Stretch features included: Markdown / audit-log / CSV / PNG export, threshold warnings (idle, low progress, anomalies, duplicates), bulk CSV import with row-by-row error log.

## 5-minute demo script
1. Sidebar → **Load sample data** → dashboard shows metrics, warnings (anomaly + duplicate), charts.
2. **Add Entry** → type `abc` as weight, collector `!` → red validation errors. Fix → saved.
3. **Records** → search `library`, filter category, page through, delete a row.
4. Stop server (Ctrl+C), `streamlit run app.py` again → data is still there (persistence).
5. **Import / Export** → upload a CSV with a bad row (see rejected-rows table), download the Markdown report + chart PNG.
